# dsh-image-demotion

Give a text-only model the pictures a browser user attached: one host plugin rewrites every durable image block into a text reference naming a file materialized under the session workspace, so the model inspects the image through its file tools instead of receiving image parts its provider cannot serialize.

A standalone plugin for the [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) — no harness source changes required.

## Model Experience

### Demoted image reference

#### What the model sees

Each image block in the admitted batch becomes one text block: `[image attachment: <name>]`, the verified media type, the encoded byte length, and the absolute path of the file written under `<session cwd>/<uploadDirectory>/<uuid>/<name>` (default `.dsh/uploads`). The replacement happens at `agent/pre-step`, before context producers and hook bridges read the batch, and the rewritten batch is what the session log records — the model-visible text is reconstructable from the log. Text and tool blocks around the image keep their positions.

When the image cannot be materialized (no workspace, no attachment service, unreadable or oversized bytes, a cancelled step), the block degrades to `[image attachment: <name>]` plus one `unavailable: <reason>` line — a model-visible failure, never a rejected turn.

#### Token effect

One short text block per image instead of provider image serialization; constant text overhead per image.

#### KV Cache effect

The reference includes a random per-image directory, so consecutive identical images invalidate the cache like any changed text block. The text is stable after the step it is written in.

## Admission stays upstream

This plugin does not open the wire: the apiproxy admission gate still rejects image parts for a model whose `resolveModelInfo` lacks image modality. Pair it with one of:

- **pi-ai (OpenAI-compatible) routes** — pure profile config; the adapter applies per-model overrides:

  ```yaml
  llm-pi-ai:
    providers:
      <route>:
        modelOverrides:
          <model-id>:
            input: [text, image]
  ```

- **`deepseek-official` route** — handled automatically: the bundle patch inserts the `deepseek-vision-bridge` row ([`src/deepseek-bridge.ts`](src/deepseek-bridge.ts)) and disables the shipped `llm-deepseek` row. The bridge re-registers the same route with [`VisionBridgeDeepSeekAdapter`](#visionbridgedeepseekadapter), reusing the `llm-deepseek` settings section, credential resolution, and model catalog, so `settings.yaml` and the Web models page keep working unchanged. The subclass only widens the reported `inputModalities`; every request path delegates to the original adapter, and the demotion rewrite guarantees no image block ever reaches its serializer.

## Build

```sh
corepack pnpm install   # dev deps come from npm; no harness checkout required
corepack pnpm run build # tsup → dist/index.js, dist/invariant.js (+ d.ts)
```

## Install into a dsh profile

This package is a dsh bundle: its manifest declares `dsh.bundle` and
[`cordis.patch.yml`](cordis.patch.yml) inserts the plugin row into the
profile's composition. Install with the standard dsh plugin command — from
this checkout (local) or from npm once published:

```sh
# 1. build (above), then install into your profile:
dsh plugin --profile <your-profile> add /path/to/dsh-image-demotion
# or, published:
dsh plugin --profile <your-profile> add @deepseek-ai/dsh-image-demotion

# 2. restart dsh with that profile. The bundle joins the profile's layer
#    stack automatically (see the profile's package.json `dsh.profile.bundles`).
```

The plugin lands in `$DSH_HOME/profiles/<your-profile>/node_modules` — never
in the harness source tree. Verify the row resolved with:

```sh
dsh --profile <your-profile> --dump-config   # shows `- id: image-demotion`
```

Optionally pair the row with a config overlay in your profile's
`cordis.patch.yml`:

```yaml
- id: image-demotion
  config:
    uploadDirectory: '.dsh/uploads'
    maxFileBytes: 52428800
    demoteModels: []   # empty = demote every image
```

## Sharing the plugin

**A. Send the tarball (simplest — the recipient never builds)**

1. You: `corepack pnpm pack` → `deepseek-ai-dsh-image-demotion-0.1.0.tgz` (a fresh build runs automatically).
2. Send the tarball (chat, drive, intranet — anything).
3. Recipient (needs dsh 0.1.0-rc.5+ installed and `pnpm` on PATH):

   ```sh
   dsh plugin --profile <their-profile> add ./deepseek-ai-dsh-image-demotion-0.1.0.tgz
   ```

   Then restart dsh with that profile.

**B. Send the source**

Recipient: `git clone` → `corepack pnpm install && corepack pnpm run build`
→ `dsh plugin --profile <their-profile> add <path-to-this-project>` (installed
as a `link:` — keep the directory around).

**C. Publish to npm**

`@deepseek-ai` is DeepSeek's scope — before publishing, rename the package in
three places: the `name` in `package.json`, the two plugin names in
[`cordis.patch.yml`](cordis.patch.yml), and `PACKAGE_NAME` in
[`src/invariant.ts`](src/invariant.ts). Then `npm publish` and the recipient
runs `dsh plugin --profile <name> add <your-package-name>`.

**Recipient prerequisites and behavior**

- dsh itself provides everything else: the `dsh plugin` command, the bundle
  patch mechanism, and the `$DSH_HOME/profiles/node_modules` fallback that
  resolves the runtime peers (cordis, dsh-*) to the installation's single
  shared copy — recipients never install the harness family by hand.
- Model routing: `deepseek-official` works out of the box (the bundle ships
  the vision bridge); pi-ai (OpenAI-compatible) routes additionally need the
  per-model `input: [text, image]` override from the admission section above.
- The plugin takes effect after the dsh host restarts.

## Config

| Key | Default | Meaning |
|---|---|---|
| `uploadDirectory` | `.dsh/uploads` | Workspace-relative root receiving demoted images |
| `maxFileBytes` | `52428800` | Maximum encoded bytes materialized for one image |
| `demoteModels` | `[]` | Model ids eligible for demotion; empty demotes every image |

Non-empty `demoteModels` consults the session's most recent request header, so the very first prompt of a session has no header yet and is not demoted.

## Durable format

The invariant companion (`@deepseek-ai/dsh-image-demotion/invariant`) validates the two text forms this package emits — the reference and the failure — wherever a demotion-marker block appears in the session log.

## Development

Tests need a dsh runtime, so they run inside a DeepSeek Harness checkout: the
script builds the package, installs it into `<dsh>/node_modules` (gitignored),
typechecks against the harness master types, runs unit tests and the real
Loader e2e with the harness's own vitest, and removes its transient test tree.
The harness sources are never touched.

```sh
corepack pnpm test          # build + install + typecheck + unit tests + e2e (in the harness)
DSH_DIR=/path/to/deepseek-harness corepack pnpm test   # point at another checkout
corepack pnpm run install:dsh   # build + install only, skip tests
corepack pnpm typecheck      # standalone editor typecheck against published types
```

## Known Limitations and Deferred Work

- **The durable image attachment is orphaned** — the apiproxy admission saves image bytes through the attachment store before pre-step rewrites the block, so the stored image is referenced by no event afterwards. Harmless disk usage; a pruning path is deferred.
- **Non-image files are not attached** — upstream wire and composer accept raster images only; generic file attachments need a separate upload channel.
- **`demoteModels` cannot see the first prompt** — model eligibility reads the previous request header, so a fresh session demotes only under the empty (all-models) default.
- **Vision-capable models are not detected automatically** — demotion applies to every image unless `demoteModels` narrows it, including models that could take the image natively.
