# dsh-image-demotion

让纯文本模型也能拿到用户在浏览器里贴的图片：一个宿主插件把每个持久化的图片 block 重写成文本引用，指向落盘在工作区里的文件，模型用自己的文件工具查看图片，而不是收到 provider 无法序列化的图片 part。

这是 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 的独立插件——不需要改动任何 harness 源码。

## 模型体验

### 图片降级引用

#### 模型看到什么

准入批次里的每个图片 block 变成一个文本 block：`[image attachment: <名称>]`、验证过的媒体类型、编码字节数，以及写入 `<会话 cwd>/<uploadDirectory>/<uuid>/<名称>`（默认 `.dsh/uploads`）的绝对路径。替换发生在 `agent/pre-step`，先于其他上下文生产者和 hook 桥读取批次；重写后的批次就是会话日志记录的内容——模型可见的文本可以从日志完整重建。图片前后的文本与工具 block 保持原有顺序。

无法落盘时（没有工作区、没有 attachment 服务、字节读不回或超限、步骤被取消），该 block 退化为 `[image attachment: <名称>]` 加一行 `unavailable: <原因>`——是模型可见的失败说明，而不是拒绝整个回合。

#### Token 影响

每张图片只多一个很短的文本 block，替代 provider 的图片序列化；每张图片的文本开销恒定。

#### KV Cache 影响

引用里带有每图随机的目录名，因此连续两张相同图片也会像任何文本变更一样使缓存失效；该步之后文本保持稳定。

## 准入仍然走上游

本插件不负责打开 wire：apiproxy 的准入闸门仍会拒绝 `resolveModelInfo` 不含图片模态的模型。需要配合其一：

- **pi-ai（OpenAI 兼容）路由** —— 纯 profile 配置；adapter 会应用按模型的覆盖：

  ```yaml
  llm-pi-ai:
    providers:
      <route>:
        modelOverrides:
          <model-id>:
            input: [text, image]
  ```

- **`deepseek-official` 路由** —— 自动处理：bundle patch 插入 `deepseek-vision-bridge` 行（[`src/deepseek-bridge.ts`](src/deepseek-bridge.ts)）并禁用内置 `llm-deepseek` 行。桥接插件用 [`VisionBridgeDeepSeekAdapter`](#visionbridgedeepseekadapter) 重新注册同一路由，复用 `llm-deepseek` settings 段、凭据解析和模型目录，因此 `settings.yaml` 与 Web 模型页完全不变。子类只放宽上报的 `inputModalities`；所有请求路径都委托给原 adapter，而降级重写保证任何图片 block 都不会到达它的序列化器。

## 构建

```sh
corepack pnpm install   # dev 依赖来自 npm；不需要 harness checkout
corepack pnpm run build # tsup → dist/index.js、dist/invariant.js（含 d.ts）
```

## 安装到 dsh profile

本包是一个 dsh bundle：manifest 声明 `dsh.bundle`，[`cordis.patch.yml`](cordis.patch.yml) 把插件行插入 profile 的组合。用标准的 dsh 插件命令安装——从本目录（本地）或发布到 npm 之后：

```sh
# 1. 先构建（见上），再装进你的 profile：
dsh plugin --profile <你的profile> add /path/to/dsh-image-demotion
# 或发布后：
dsh plugin --profile <你的profile> add @deepseek-ai/dsh-image-demotion

# 2. 用该 profile 重启 dsh。bundle 会自动加入 profile 的层栈
#    （见 profile 目录 package.json 的 dsh.profile.bundles）。
```

插件会落到 `$DSH_HOME/profiles/<你的profile>/node_modules`——永远不会进 harness 源码树。验证该行已解析：

```sh
dsh --profile <你的profile> --dump-config   # 应显示 `- id: image-demotion`
```

可选：在你的 profile `cordis.patch.yml` 里叠加一行配置：

```yaml
- id: image-demotion
  config:
    uploadDirectory: '.dsh/uploads'
    maxFileBytes: 52428800
    demoteModels: []   # 空 = 对每张图片降级
```

## 分享插件

**A. 发安装包（最简单，对方无需构建）**

1. 你：`corepack pnpm pack` → 生成 `deepseek-ai-dsh-image-demotion-0.1.0.tgz`（自动先构建）
2. 把 tgz 发给对方（聊天、网盘、内网都行）
3. 对方（已装 dsh 0.1.0-rc.5+，PATH 上有 pnpm）：

   ```sh
   dsh plugin --profile <他的profile> add ./deepseek-ai-dsh-image-demotion-0.1.0.tgz
   ```

   然后用该 profile 重启 dsh。

**B. 发源码**

对方：`git clone` → `corepack pnpm install && corepack pnpm run build`
→ `dsh plugin --profile <他的profile> add <本项目路径>`（以 `link:` 安装，目录要保留）

**C. 发布到 npm**

`@deepseek-ai` 是 DeepSeek 的 scope——发布前先改三处名字：`package.json` 的 `name`、[`cordis.patch.yml`](cordis.patch.yml) 里的两处插件名、[`src/invariant.ts`](src/invariant.ts) 的 `PACKAGE_NAME`。然后 `npm publish`，对方执行 `dsh plugin --profile <name> add <你的包名>`。

**对方的前提与说明**

- dsh 本身提供其余一切：`dsh plugin` 命令、bundle patch 机制，以及 `$DSH_HOME/profiles/node_modules` 回退目录——运行时 peer（cordis、dsh 家族）由它解析到安装目录的唯一共享副本，对方永远不用手工装 harness 家族。
- 模型路由：`deepseek-official` 开箱即用（bundle 自带视觉桥接）；pi-ai（OpenAI 兼容）路由还需按上文准入配置给目标模型加 `input: [text, image]`。
- 重启 dsh host 后插件才生效。

## 配置

| 键 | 默认值 | 含义 |
|---|---|---|
| `uploadDirectory` | `.dsh/uploads` | 接收降级图片的工作区相对根目录 |
| `maxFileBytes` | `52428800` | 单张图片允许落盘的最大编码字节数 |
| `demoteModels` | `[]` | 允许降级的模型 id 列表；为空表示对所有图片降级 |

`demoteModels` 非空时读取会话最近的 request header，因此会话的第一条提示还没有 header，不会被降级。

## 持久化格式

不变式伴随插件（`@deepseek-ai/dsh-image-demotion/invariant`）校验本包产出的两种文本形式——引用与失败说明——凡日志中出现降级标记 block 的地方都要符合其一。

## 开发

测试需要 dsh 运行时，所以在一个 DeepSeek Harness checkout 内执行：脚本构建包 → 装进 `<dsh>/node_modules`（gitignored）→ 用 harness master 类型做类型检查 → 用 harness 自己的 vitest 跑单元测试和真实 Loader e2e → 清掉临时测试树。harness 源码零改动。

```sh
corepack pnpm test          # 构建 + 安装 + 类型检查 + 单元测试 + e2e（在 harness 内）
DSH_DIR=/path/to/deepseek-harness corepack pnpm test   # 指向别的 checkout
corepack pnpm run install:dsh   # 只构建 + 安装，跳过测试
corepack pnpm typecheck      # 独立编辑器类型检查（用已发布类型）
```

## 已知限制与后续工作

- **持久化图片附件成为孤儿** —— apiproxy 准入在 pre-step 重写之前就已把图片字节存入 attachment 存储，重写后没有任何事件引用它。只占磁盘、无功能影响；清理路径留待后续。
- **不支持非图片文件** —— 上游 wire 与 composer 只接受栅格图片；通用文件附件需要单独的传输通道。
- **`demoteModels` 看不到第一条提示** —— 模型筛选读的是上一次 request header，所以新会话只有用空列表（全部模型）默认值时才会降级。
- **不自动识别视觉模型** —— 除非用 `demoteModels` 收窄，否则每张图片都会被降级，包括本可原生接收图片的模型。
